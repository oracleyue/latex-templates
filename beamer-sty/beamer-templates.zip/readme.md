The `beamer43.tex` and `beamer169.tex` forks the powerpoint template of LCSB. I only put the logo on the first page. The `beamer43` also inserts the line surrounding the logos, while `beamer169` not.

Both of them use `bibentry` package to insert the citation, which will put full citation entries in the footnote of each page. You may change the following line to refer to your bibtex library files (files with extension `.bib`; e.g. here is `library.bib` under `./ref/`).

```
\nobibliography{./ref/library}
```

Maybe a better solution of citation is `biblatex`, used in my defense, which only put the citation key (e.g. "Goncalves (2008)") on the pages, and the full citation entries will be place at the last page. This is implemented in `beamer-phd-light.tex` and `beamer-phd-dark.tex`. They both use the style files created by myself, placed in `./styles/`. You may replace the `bibentry` part in `beamer43(169).tex` by the `biblatex` part in `zyuebeamer.sty`. If you fail to do that, let me know and I can help. (I didn't update `beamer43(169).tex` since I stop using the LCSB title page.)

Update: an updated version of `beamer43.tex` using `biblatex` is provided by `beamer43-biblatex.tex`, which uses the `lcsbbeamer.sty` style file.